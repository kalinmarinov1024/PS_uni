﻿using System.Windows;

namespace WPFhello
{
    /// <summary>
    /// Interaction logic for MyMessage.xaml
    /// </summary>
    public partial class MyMessage : Window
    {
        public MyMessage()
        {
            InitializeComponent();
        }
    }
}
