﻿namespace UserLogin
{
    public class User
    {
        public System.String username
        { get; set; }
        public System.String password
        { get; set; }
        public System.String facultyNumber
        { get; set; }
        public System.Int32? userRole
        { get; set; }
        public System.DateTime? created
        { get; set; }
        public System.DateTime? validTime
        { get; set; }
        public System.Int32? UserId
        { get; set; }

    }
}
