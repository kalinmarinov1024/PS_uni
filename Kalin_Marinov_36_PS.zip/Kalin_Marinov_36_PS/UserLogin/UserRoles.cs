﻿namespace UserLogin
{
    public enum UserRoles
    {
        ANONYMOUS, ADMIN, INSPECTOR, PROFESSOR, STUDENT
    }
}