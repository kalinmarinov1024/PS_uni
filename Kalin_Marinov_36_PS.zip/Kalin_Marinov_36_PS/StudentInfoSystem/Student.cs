﻿namespace StudentInfoSystem
{
    public class Student
    {
        public string name { get; set; }
        public string middleName { get; set; }
        public string familyName { get; set; }
        public string faculty { get; set; }
        public string specialty { get; set; }
        public string educationalDegree { get; set; }
        public string status { get; set; }
        public string facultyNumber { get; set; }
        public int course { get; set; }
        public int flow { get; set; }
        public int group { get; set; }
        public int StudentId { get; set; }
    }
}
