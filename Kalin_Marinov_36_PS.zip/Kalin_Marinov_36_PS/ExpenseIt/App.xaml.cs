﻿using System.Windows;

namespace ExpenseIt
{
    public partial class App : Application
    {
    }
}
